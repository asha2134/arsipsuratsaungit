
<?php
include 'config.php';
$result = mysqli_query($conn, "SELECT * FROM suratkeluar");
?>

<h2>Data Surat Keluar</h2>
<a href="dashboard.php">Kembali</a>
<table border="1" cellpadding="10">
  <tr>
    <th>No</th><th>No Surat</th><th>Judul</th><th>Tujuan</th><th>Tanggal Keluar</th><th>Keterangan</th>
  </tr>
  <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= $row['nosurat_keluar'] ?></td>
    <td><?= $row['judulsuratkeluar'] ?></td>
    <td><?= $row['tujuan'] ?></td>
    <td><?= $row['tanggalkeluar'] ?></td>
    <td><?= $row['keterangan'] ?></td>
  </tr>
  <?php } ?>
</table>
