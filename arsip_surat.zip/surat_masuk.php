
<?php
include 'config.php';
$result = mysqli_query($conn, "SELECT * FROM suratmasuk");
?>

<h2>Data Surat Masuk</h2>
<a href="dashboard.php">Kembali</a>
<table border="1" cellpadding="10">
  <tr>
    <th>No</th><th>No Surat</th><th>Judul</th><th>Asal</th><th>Tgl Masuk</th><th>Tgl Keluar</th><th>Keterangan</th>
  </tr>
  <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= $row['no_surat'] ?></td>
    <td><?= $row['judul_surat'] ?></td>
    <td><?= $row['asal_surat'] ?></td>
    <td><?= $row['tanggal_masuk'] ?></td>
    <td><?= $row['tanggal_keluar'] ?></td>
    <td><?= $row['keterangan'] ?></td>
  </tr>
  <?php } ?>
</table>
