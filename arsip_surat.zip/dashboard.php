
<?php
session_start();
if (!isset($_SESSION['user'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
  <title>Dashboard Arsip Surat</title>
  <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body class="p-4">
  <h3>Selamat datang, <?php echo $_SESSION['user']['nama_lengkap']; ?> (<?php echo $_SESSION['user']['level']; ?>)</h3>
  <a href="logout.php" class="btn btn-danger btn-sm mb-3">Logout</a>
  <ul>
    <li><a href="surat_masuk.php">Surat Masuk</a></li>
    <li><a href="surat_keluar.php">Surat Keluar</a></li>
    <li><a href="disposisi.php">Disposisi</a></li>
  </ul>
</body>
</html>
