
<?php
include 'config.php';
$result = mysqli_query($conn, "SELECT * FROM disposisi");
?>

<h2>Data Disposisi</h2>
<a href="dashboard.php">Kembali</a>
<table border="1" cellpadding="10">
  <tr>
    <th>No</th><th>Pengisi</th><th>Tujuan</th><th>Instruksi</th><th>Catatan</th>
  </tr>
  <?php $no = 1; while ($row = mysqli_fetch_assoc($result)) { ?>
  <tr>
    <td><?= $no++ ?></td>
    <td><?= $row['pengisi'] ?></td>
    <td><?= $row['tujuan'] ?></td>
    <td><?= $row['instruksi'] ?></td>
    <td><?= $row['catatan'] ?></td>
  </tr>
  <?php } ?>
</table>
